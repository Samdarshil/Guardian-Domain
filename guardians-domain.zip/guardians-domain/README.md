# Guardian's Domain

Darshil Samson's interactive 3D portfolio. React + TypeScript + Vite +
Three.js + React Three Fiber + Zustand, per the project brief.

## Run it

```bash
npm install
npm run dev
```

Build for production with `npm run build` (verified clean — no TypeScript
errors, no lint errors). Every pass has been checked with a real
headless-browser screenshot at desktop and mobile widths — including a
full run through the opening sequence beat by beat — before shipping, not
just "the build didn't error."

## What's actually here (as of this pass)

**Built and verified:**

- Project scaffold — Vite + React 19 + TypeScript, architecture folders per
  the brief (`app/ components/ scene/ systems/ content/ state/ hooks/
  styles/ utils/`)
- **Content/data layer** (`src/content/`) — identity, education, experience,
  evidence, all 5 projects, Alex's dialogue lines, and the opening sequence
  script, fully populated with verified facts. See `src/content/README.md`
  for exactly what's sourced from where. This is the part meant to outlive
  every visual iteration: adding a 6th project means adding an entry to
  `projects.ts`, nothing else.
- **The opening cinematic** (`src/scene/Opening.tsx` +
  `content/openingBeats.ts`) — the full §9 beat sequence: black, a single
  star, the universe revealing, four narrative text beats, a title card,
  then handoff into the real cockpit. Every line of text is either a stated
  fact (Baran; the Railway Reservation System; Python/SQL) or non-factual
  thematic copy — nothing invents a detail about Darshil. Always-focusable
  "Skip intro" button, works from frame one. Verified with a full beat-by-
  beat screenshot pass, screen-reader announcements via `aria-live`.
- Zustand store — `mode` (normal/recruiter), `reducedMotion`, and
  `activeRegion` are all real and wired up. The destination panel sets
  `activeRegion`; the nav readout and Alex's dialogue both react to it.
- **Cockpit shell** (`src/components/hud/`) — windshield frame, a nav
  readout (mode + locked target + a genuinely live clock, no fabricated
  telemetry), a radar widget (real sweep animation, honestly labeled "no
  signals — system not yet online"), and a destination panel that actually
  sets state when you lock a region (labeled "lock target only — travel
  isn't built yet"). HUD panels stagger in on arrival for a "systems
  booting" feel. WebGL-missing fallback is real — every panel is plain
  HTML/CSS, identical whether or not the 3D scene renders (the opening is
  skipped straight to the fallback cockpit in that case, since it's a 3D
  sequence with nothing to render).
- **Alex** (`content/alexLines.ts` + `AlexDock.tsx`) — a real, deterministic
  dialogue layer. Plays his canonical intro (brief §10, verbatim) once the
  cockpit loads, then reacts live to whichever region is locked in with a
  line per destination, all grounded in already-verified content. An "I
  don't have that yet" fallback (`alexUnknownLine`) exists per §11's
  never-hallucinate rule, ready for whenever real Q&A gets built.
- Design tokens (`src/styles/tokens.css`) — the navy/glass/restrained-cyan
  palette from the brief, IBM Plex Sans/Mono pairing (self-hosted via
  @fontsource, no external font CDN dependency), `prefers-reduced-motion`
  wired through the camera rig, the radar sweep, the opening's animations,
  and Alex's pulse indicator.
- The 4 supplied credential PDFs are bundled unaltered in
  `public/documents/` and wired into `evidence.ts` by real file path.

**Fixed during this pass, worth knowing about:** React Three Fiber's
`<Canvas>` applies its own inline `position: relative` to its wrapper div,
which silently beat an external stylesheet's `position: absolute` on the
same element — the opening's text was rendering correctly but 900px below
the visible viewport as a result. Only caught because of the actual
screenshot pass, not the build. Fixed by passing `style={{ position:
"absolute", inset: 0 }}` directly to `<Canvas>` in both `Opening.tsx` and
`App.tsx`. Worth remembering if a future `<Canvas>` gets added anywhere
else in this project.

**Not built yet — do not assume these exist:**

- Actual travel/camera movement between world regions (locking a
  destination sets state; nothing flies the camera anywhere yet)
- The Radar system's real signal logic (known/unknown/anomaly/transient) —
  only the visual sweep shell exists, no blips or detection
- Alex answering free-form questions — today he only reacts to destination
  selection with pre-written lines, there's no input/query surface yet
- Recruiter Mode's actual guided flow (the toggle switches `mode` in the
  store; nothing reads it to change the UI yet)
- The Archive document viewer (evidence data + real PDFs are ready to be
  read by one; the viewer component itself doesn't exist)
- Modeled 3D cockpit geometry (currently a CSS windshield-frame stand-in)
- Performance tiers, audio, and the realistic celestial rendering (Null
  black hole, real planets)
- "Remember they've seen the opening" persistence (it replays every visit
  right now — straightforward to add with localStorage, skipped for this
  pass to avoid scope creep)

## Known trade-off

The production JS bundle is ~1MB (mostly Three.js) and Vite warns about
chunk size. Expected at this stage — not a bug. Worth addressing with
`React.lazy`/dynamic import once there's more scene content to actually
split, rather than now.

## Next milestones (per the brief's vertical-slice order)

Radar (real signal logic) → Travel → Origin → one memory → Forge → Career
Guardian AI card → return to ship.

Opening, Cockpit, and Alex are all done — built in that non-brief order
(Cockpit and Alex before Opening) on purpose, so the opening's ending had
something real to transition into instead of placeholder versions of both.

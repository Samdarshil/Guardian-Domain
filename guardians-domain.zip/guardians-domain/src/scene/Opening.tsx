import { useEffect, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { Starfield } from "./Starfield";
import { openingBeats } from "../content/openingBeats";
import styles from "./Opening.module.css";

interface OpeningProps {
  onComplete: () => void;
}

/**
 * Plays the brief §9 beat sequence, then hands off to the cockpit (App.tsx
 * mounts the real cockpit once onComplete fires — COCKPIT/SYSTEM BOOT/ALEX/
 * MODE SELECTION are that handoff, not more beats in here). Auto-advances
 * on a timer; Skip always works, from the very first frame, for anyone who
 * doesn't want to sit through it twice.
 */
export function Opening({ onComplete }: OpeningProps) {
  const [index, setIndex] = useState(0);
  const skipRef = useRef<HTMLButtonElement>(null);
  const beat = openingBeats[index];

  useEffect(() => {
    skipRef.current?.focus();
  }, []);

  useEffect(() => {
    const id = setTimeout(() => {
      if (index < openingBeats.length - 1) {
        setIndex((i) => i + 1);
      } else {
        onComplete();
      }
    }, beat.durationMs);
    return () => clearTimeout(id);
  }, [index, beat.durationMs, onComplete]);

  const showCanvas = beat.kind !== "black" && beat.kind !== "star";

  return (
    <div className={styles.root}>
      {showCanvas && (
        <Canvas
          className={styles.canvas}
          style={{ position: "absolute", inset: 0 }}
          camera={{ position: [0, 0, 8], fov: 55 }}
          gl={{ antialias: true, alpha: false }}
        >
          <color attach="background" args={["#04060b"]} />
          <Starfield />
        </Canvas>
      )}

      {beat.kind === "star" && (
        <div className={styles.star} aria-hidden="true" />
      )}

      {(beat.kind === "text" || beat.kind === "title") && (
        <div className={styles.scrim} aria-hidden="true" />
      )}

      <div className={styles.content} aria-live="polite">
        {beat.kind === "text" && (
          <p key={beat.id} className={styles.text}>
            {beat.text}
          </p>
        )}
        {beat.kind === "title" && (
          <h1 key={beat.id} className={styles.title}>
            {beat.text}
          </h1>
        )}
      </div>

      <button
        ref={skipRef}
        type="button"
        className={styles.skip}
        onClick={onComplete}
      >
        Skip intro
      </button>
    </div>
  );
}

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useDomainStore } from "../state/useDomainStore";

interface StarfieldProps {
  count?: number;
}

/**
 * A static-positioned, slowly-drifting star field.
 *
 * This is deliberately the simplest possible scene: it exists to prove the
 * render pipeline (Canvas -> Scene -> real geometry on screen) works before
 * any of the actual cinematic/cockpit systems are built on top of it. Point
 * count is kept low; the real performance-tier system (Ultra/High/Balanced/
 * Lite/Accessible from the brief) is not implemented yet — see project
 * README "Status".
 */
export function Starfield({ count = 2600 }: StarfieldProps) {
  const pointsRef = useRef<THREE.Points>(null);
  const reducedMotion = useDomainStore((s) => s.reducedMotion);

  const positions = useMemo(() => {
    // oxlint(react/purity): intentional — this generates the star field
    // once per `count` change, not on every render. React Compiler isn't
    // enabled in this build, so there's no auto-memoization to break; the
    // explicit dependency array is what actually controls re-computation.
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      // Distribute inside a sphere shell so stars read as depth, not a flat wall.
      const radius = 40 + Math.random() * 160;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      arr[i * 3 + 2] = radius * Math.cos(phi);
    }
    return arr;
  }, [count]);

  useFrame((_, delta) => {
    if (!pointsRef.current || reducedMotion) return;
    // Slow ambient drift only — nothing that reads as motion sickness territory.
    pointsRef.current.rotation.y += delta * 0.006;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.55}
        sizeAttenuation
        color="#e7ecf5"
        transparent
        opacity={0.85}
      />
    </points>
  );
}

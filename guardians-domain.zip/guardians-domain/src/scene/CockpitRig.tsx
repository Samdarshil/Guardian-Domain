import { useRef, type ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useDomainStore } from "../state/useDomainStore";

interface CockpitRigProps {
  children: ReactNode;
}

const MAX_YAW = 0.12; // radians — deliberately small, this is a windshield, not a free camera
const MAX_PITCH = 0.08;
const EASE = 0.04;

/**
 * Wraps scene content in a group that eases toward a pointer-driven offset.
 * Reads reducedMotion from the store and, when set, holds the rig steady
 * instead of tracking the pointer.
 */
export function CockpitRig({ children }: CockpitRigProps) {
  const groupRef = useRef<THREE.Group>(null);
  const reducedMotion = useDomainStore((s) => s.reducedMotion);

  useFrame((state) => {
    if (!groupRef.current) return;
    const targetY = reducedMotion ? 0 : state.pointer.x * MAX_YAW;
    const targetX = reducedMotion ? 0 : -state.pointer.y * MAX_PITCH;
    groupRef.current.rotation.y +=
      (targetY - groupRef.current.rotation.y) * EASE;
    groupRef.current.rotation.x +=
      (targetX - groupRef.current.rotation.x) * EASE;
  });

  return <group ref={groupRef}>{children}</group>;
}

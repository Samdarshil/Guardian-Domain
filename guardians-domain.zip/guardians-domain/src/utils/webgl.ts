/**
 * Cheap WebGL availability check. The brief is explicit: if 3D rendering
 * fails, the site must still work — never a blank page. App.tsx uses this
 * to decide between the scene and the semantic fallback layout.
 */
export function isWebGLAvailable(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
    );
  } catch {
    return false;
  }
}

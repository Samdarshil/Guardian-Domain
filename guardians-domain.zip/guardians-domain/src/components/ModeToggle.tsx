import { useDomainStore } from "../state/useDomainStore";
import styles from "./ModeToggle.module.css";

export function ModeToggle() {
  const mode = useDomainStore((s) => s.mode);
  const setMode = useDomainStore((s) => s.setMode);

  return (
    <div className={styles.toggle} role="radiogroup" aria-label="Experience mode">
      <button
        type="button"
        role="radio"
        aria-checked={mode === "normal"}
        className={mode === "normal" ? styles.active : undefined}
        onClick={() => setMode("normal")}
      >
        Normal
      </button>
      <button
        type="button"
        role="radio"
        aria-checked={mode === "recruiter"}
        className={mode === "recruiter" ? styles.active : undefined}
        onClick={() => setMode("recruiter")}
      >
        Recruiter
      </button>
    </div>
  );
}

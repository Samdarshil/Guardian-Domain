import styles from "./WindshieldFrame.module.css";

/**
 * A CSS-only viewport frame standing in for modeled 3D cockpit geometry.
 * Modeling an actual cockpit interior mesh is real asset work for a later
 * pass — this restrained vignette + bracket treatment reads as "looking out
 * a window" without pretending to be more than it is.
 */
export function WindshieldFrame() {
  return (
    <div className={styles.frame} aria-hidden="true">
      <span className={`${styles.bracket} ${styles.tl}`} />
      <span className={`${styles.bracket} ${styles.tr}`} />
      <span className={`${styles.bracket} ${styles.bl}`} />
      <span className={`${styles.bracket} ${styles.br}`} />
    </div>
  );
}

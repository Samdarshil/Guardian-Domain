import type { ReactNode } from "react";
import styles from "./HudPanel.module.css";

interface HudPanelProps {
  label?: string;
  children: ReactNode;
  className?: string;
}

/**
 * The one recurring surface treatment for cockpit chrome: glass, hairline
 * border, restrained glow. Every HUD widget should compose this rather than
 * inventing its own panel style — that's what keeps the cockpit from
 * reading as a pile of separately-designed widgets.
 */
export function HudPanel({ label, children, className }: HudPanelProps) {
  return (
    <section className={[styles.panel, className].filter(Boolean).join(" ")}>
      {label && <p className={styles.label}>{label}</p>}
      {children}
    </section>
  );
}

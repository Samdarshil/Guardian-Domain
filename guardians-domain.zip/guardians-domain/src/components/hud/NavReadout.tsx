import { useEffect, useState } from "react";
import { HudPanel } from "./HudPanel";
import { useDomainStore } from "../../state/useDomainStore";
import { worldRegions } from "../../content/world";
import styles from "./NavReadout.module.css";

export function NavReadout() {
  const mode = useDomainStore((s) => s.mode);
  const activeRegion = useDomainStore((s) => s.activeRegion);

  // A real, live clock — not decorative fake telemetry. Everything else in
  // this panel reflects actual app state.
  const [time, setTime] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const region = worldRegions.find((r) => r.id === activeRegion);

  return (
    <HudPanel label="Navigation" className={styles.readout}>
      <dl className={styles.grid}>
        <dt>Mode</dt>
        <dd>{mode === "recruiter" ? "Recruiter" : "Normal"}</dd>
        <dt>Locked on</dt>
        <dd>{region ? region.name : "— none —"}</dd>
        <dt>Ship time</dt>
        <dd>{time.toLocaleTimeString([], { hour12: false })}</dd>
      </dl>
    </HudPanel>
  );
}

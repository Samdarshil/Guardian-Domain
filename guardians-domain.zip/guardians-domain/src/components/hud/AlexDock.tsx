import { useEffect, useState } from "react";
import { HudPanel } from "./HudPanel";
import { useDomainStore } from "../../state/useDomainStore";
import { worldRegions } from "../../content/world";
import { alexIntro, alexRegionLines, alexIdleLine } from "../../content/alexLines";
import styles from "./AlexDock.module.css";

type Phase = "intro" | "idle";
const LINE_HOLD_MS = 2400;

/**
 * Alex's dialogue is deterministic (brief §35): a scripted intro straight
 * from the brief, then a line per selected region sourced from already-
 * verified content. Nothing here is generated or guessed at render time.
 */
export function AlexDock() {
  const activeRegion = useDomainStore((s) => s.activeRegion);
  const [introIndex, setIntroIndex] = useState(0);
  const [phase, setPhase] = useState<Phase>("intro");

  useEffect(() => {
    if (phase !== "intro") return;
    if (introIndex < alexIntro.length - 1) {
      const id = setTimeout(() => setIntroIndex((i) => i + 1), LINE_HOLD_MS);
      return () => clearTimeout(id);
    }
    const id = setTimeout(() => setPhase("idle"), LINE_HOLD_MS);
    return () => clearTimeout(id);
  }, [phase, introIndex]);

  const region = worldRegions.find((r) => r.id === activeRegion);
  const line =
    phase === "intro"
      ? alexIntro[introIndex]
      : region
        ? alexRegionLines[region.id]
        : alexIdleLine;

  return (
    <HudPanel label="Companion" className={styles.wrap}>
      <div className={styles.header}>
        <span className={styles.avatar} aria-hidden="true">
          <span className={styles.pulse} />
        </span>
        <p className={styles.name}>Alex</p>
      </div>
      <p className={styles.line} aria-live="polite">
        {line}
      </p>
    </HudPanel>
  );
}

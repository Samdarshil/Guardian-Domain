import { HudPanel } from "./HudPanel";
import styles from "./RadarWidget.module.css";

/**
 * The actual Radar system (known/unknown/anomaly/transient signal states,
 * from the brief's section 16) doesn't exist yet — see systems/README.md.
 * This is the visual shell only: a real sweep animation, no fabricated
 * blips or signal data standing in for a system that isn't built.
 */
export function RadarWidget() {
  return (
    <HudPanel label="Radar" className={styles.wrap}>
      <div className={styles.scope}>
        <div className={styles.ring} />
        <div className={styles.ring} style={{ inset: "22%" }} />
        <div className={styles.ring} style={{ inset: "44%" }} />
        <div className={styles.crosshair} />
        <div className={styles.sweep} />
      </div>
      <p className={styles.status}>No signals — system not yet online</p>
    </HudPanel>
  );
}

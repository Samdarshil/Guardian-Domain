import { HudPanel } from "./HudPanel";
import { useDomainStore } from "../../state/useDomainStore";
import { worldRegions } from "../../content/world";
import styles from "./DestinationPanel.module.css";

export function DestinationPanel() {
  const activeRegion = useDomainStore((s) => s.activeRegion);
  const setActiveRegion = useDomainStore((s) => s.setActiveRegion);

  // The Null is discovered, not listed — see world.ts.
  const visibleRegions = worldRegions.filter((r) => !r.hiddenFromNav);

  return (
    <HudPanel label="Destinations" className={styles.wrap}>
      <ul className={styles.list}>
        {visibleRegions.map((region) => (
          <li key={region.id}>
            <button
              type="button"
              className={activeRegion === region.id ? styles.active : undefined}
              aria-pressed={activeRegion === region.id}
              onClick={() =>
                setActiveRegion(activeRegion === region.id ? null : region.id)
              }
            >
              <span>{region.name}</span>
              <span className={styles.focus}>{region.focus}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className={styles.note}>Lock target only — travel isn&apos;t built yet.</p>
    </HudPanel>
  );
}

import type { WorldRegion } from "./types";

// Source: README.md, section 14 "WORLD STRUCTURE". Eight destinations,
// deliberately — the brief is explicit that not every idea becomes its own
// planet. The Null is real but excluded from primary navigation; it's meant
// to be found, not listed.
export const worldRegions: WorldRegion[] = [
  {
    id: "the-heart",
    name: "The Heart",
    focus: "Identity",
    description: "The central core — who Guardian is.",
  },
  {
    id: "origin",
    name: "Origin",
    focus: "Education & childhood",
    description: "Childhood, education, and the beginning of the technological journey.",
  },
  {
    id: "the-forge",
    name: "The Forge",
    focus: "Projects",
    description: "Projects and creations — what's actually been built.",
  },
  {
    id: "the-mind",
    name: "The Mind",
    focus: "Technical skills",
    description: "Technical capabilities and stack, mapped to real projects.",
  },
  {
    id: "orbit",
    name: "Orbit",
    focus: "Professional experience",
    description: "Internships, memberships, and professional history.",
  },
  {
    id: "archive",
    name: "Archive",
    focus: "Credentials",
    description: "Credentials and the supporting documentation behind them.",
  },
  {
    id: "frontier",
    name: "Frontier",
    focus: "Future direction",
    description: "Where this is all heading next.",
  },
  {
    id: "the-null",
    name: "The Null",
    focus: "Hidden",
    description: "A region discovered, not navigated to.",
    hiddenFromNav: true,
  },
];

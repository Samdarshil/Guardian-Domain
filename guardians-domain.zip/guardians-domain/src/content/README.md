# Content layer

Every file here is data, not markup — the 3D scene and UI read from this
layer rather than hardcoding copy. Adding a project should mean adding an
entry to `projects.ts`, never touching the scene code.

## Source of truth, per file

| File | Source | Tier |
|---|---|---|
| `identity.ts` | README.md brief §7 + github.com/Samdarshil bio | Creator-supplied |
| `education.ts` | README.md brief §22 | README / spec (no independent document exists for pre-university stages) |
| `experience.ts` | Offer letter, certificate, LOR, 451 Alliance letter | **Official document** (highest tier) |
| `evidence.ts` | The 4 supplied PDFs, copied unaltered into `/public/documents` | **Official document** |
| `projects.ts` | Live repos: github.com/Samdarshil/Career-Guardian-AI, github.com/Samdarshil/DecodeLabs-Internship-Projects | **Live repository** (fetched and confirmed, not assumed) |
| `world.ts` | README.md brief §14 | README / spec |

## Rules for editing this layer

- Never add a stat, date, employer, repo link, or technology that isn't
  traceable to one of the sources above. If it's not here, it doesn't ship.
- If a fact is genuinely unknown, leave it out or mark it — don't fill the
  gap with something plausible.
- The 451 Alliance entry is a **research-community membership**, not a job.
  Keep `kind`/`kindLabel` intact when editing — that distinction is load-
  bearing for how Orbit presents it.
- `projects.ts` repository links point at specific verified subfolders
  (`Project 01`–`04`) inside `DecodeLabs-Internship-Projects`. If that repo's
  structure changes, update the links — don't leave stale ones.

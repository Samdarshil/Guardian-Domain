export type OpeningBeatKind = "black" | "star" | "universe" | "text" | "title";

export interface OpeningBeat {
  id: string;
  kind: OpeningBeatKind;
  text?: string;
  durationMs: number;
}

/**
 * Beat order follows the brief §9 conceptual sequence:
 * BLACK -> STAR -> UNIVERSE -> CHILDHOOD MEMORY -> TECHNOLOGY -> QUESTION ->
 * FIRST CREATION -> SPACESHIP -> COCKPIT -> SYSTEM BOOT -> ALEX ->
 * GUARDIAN'S DOMAIN -> MODE SELECTION.
 *
 * This file only covers the beats up through the title card. COCKPIT,
 * SYSTEM BOOT, ALEX, and MODE SELECTION are the handoff into the already-
 * built cockpit shell (App.tsx mounts it once this sequence completes) —
 * Alex's own intro already plays itself on mount, so it isn't duplicated
 * here.
 *
 * Every line of text below either states a real, verified fact (Baran; the
 * Railway Reservation System; Python/SQL) or is a thematic, non-factual
 * line — nothing here invents a detail about Darshil that isn't already in
 * education.ts.
 */
export const openingBeats: OpeningBeat[] = [
  { id: "black", kind: "black", durationMs: 1100 },
  { id: "star", kind: "star", durationMs: 1500 },
  { id: "universe", kind: "universe", durationMs: 1900 },
  {
    id: "childhood",
    kind: "text",
    text: "Somewhere in Baran, a kid was more interested in how things worked than what they were.",
    durationMs: 3600,
  },
  {
    id: "technology",
    kind: "text",
    text: "Not just using it. Wanting to understand it.",
    durationMs: 2600,
  },
  {
    id: "question",
    kind: "text",
    text: "What if you could build the things you used to just imagine?",
    durationMs: 3200,
  },
  {
    id: "first-creation",
    kind: "text",
    text: "The first real answer: a Railway Reservation System. Python, SQL, and a lot of trial and error.",
    durationMs: 3800,
  },
  { id: "spaceship", kind: "universe", durationMs: 2000 },
  { id: "title", kind: "title", text: "GUARDIAN'S DOMAIN", durationMs: 2400 },
];

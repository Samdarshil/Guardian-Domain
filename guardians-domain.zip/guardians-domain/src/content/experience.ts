import type { ExperienceEntry } from "./types";

// Every field below is verified against a supplied document (see evidence.ts
// for the originals). Do not add responsibilities, titles, or dates that
// aren't in those documents — this is the top of the source-of-truth
// hierarchy and should never be "improved" with invented specifics.
export const experience: ExperienceEntry[] = [
  {
    id: "decodelabs",
    organization: "DecodeLabs",
    role: "Artificial Intelligence (AI) Intern",
    kind: "internship",
    kindLabel: "Internship",
    mode: "Remote / Virtual",
    period: "25 May 2026 – 25 June 2026",
    summary:
      "Department/Track: Artificial Intelligence (AI). Completed via the DecodeLabs Virtual Internship Program — a learning-focused internship built around assigned projects, milestones, and mentor-led sessions.",
    highlights: [
      "Built four complete software projects from scratch during the internship (see The Forge)",
      "Received a Certificate of Completion, issued 26 June 2026 (Student ID AI0626913)",
      "Received a Letter of Recommendation, dated 29 June 2026",
    ],
    evidenceIds: [
      "decodelabs-offer-letter",
      "decodelabs-certificate",
      "decodelabs-recommendation-letter",
    ],
  },
  {
    id: "451-alliance",
    organization: "451 Alliance — S&P Global Market Intelligence",
    role: "Leading Indicator Member",
    kind: "membership",
    kindLabel: "Research Community Membership",
    period: "2026 –",
    summary:
      "Membership in the Leading Indicator community of tech-adjacent professionals and consumer tech enthusiasts. Not an employment relationship — the welcome letter itself describes a research-panel membership: weekly research reports, a tech-spending dashboard, a weekly digest, partner discounts, and participation in think-tank surveys.",
    highlights: [
      "Access to weekly IT & business trend research reports",
      "Access to the Tech Demand Indicator dashboard",
      "Participates in think-tank research surveys",
    ],
    evidenceIds: ["451-alliance-invitation"],
  },
];

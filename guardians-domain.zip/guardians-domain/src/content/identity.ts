import type { Identity } from "./types";

// Source: README.md (Guardian's Domain brief), section 7 "CREATOR IDENTITY",
// cross-checked against github.com/Samdarshil profile bio.
export const identity: Identity = {
  professionalName: "Darshil Samson",
  narrativeName: "Guardian",
  tagline: "Turning Ideas into meaningful digital experiences.",
  location: "Jaipur, Rajasthan, India",
  links: [
    { label: "GitHub", url: "https://github.com/Samdarshil" },
    {
      label: "LinkedIn",
      url: "https://www.linkedin.com/in/darshil-samson-30a71a346",
    },
    { label: "LeetCode", url: "https://leetcode.com/u/Samdarshil" },
    { label: "X", url: "https://x.com/Samsondarshil" },
    { label: "Email", url: "mailto:samsondarshil@gmail.com" },
  ],
};

import type { EvidenceDocument } from "./types";

// Each `file` path resolves under /public/documents — the exact PDF the
// creator supplied, copied byte-for-byte. The Archive's document viewer
// must open these originals directly; never a reconstruction, and never a
// fabricated "verification" graphic layered on top.
export const evidence: EvidenceDocument[] = [
  {
    id: "decodelabs-offer-letter",
    title: "Offer of Internship",
    issuer: "DecodeLabs",
    dateLabel: "25 May 2026",
    file: "/documents/decodelabs-offer-letter.pdf",
  },
  {
    id: "decodelabs-certificate",
    title: "Certificate of Completion",
    issuer: "DecodeLabs Virtual Internship Program",
    dateLabel: "Issued 26 June 2026",
    file: "/documents/decodelabs-certificate.pdf",
    note: "Student ID AI0626913 · Duration 25 May – 25 June 2026",
  },
  {
    id: "decodelabs-recommendation-letter",
    title: "Letter of Recommendation",
    issuer: "DecodeLabs",
    dateLabel: "29 June 2026",
    file: "/documents/decodelabs-recommendation-letter.pdf",
  },
  {
    id: "451-alliance-invitation",
    title: "Welcome to the 451 Alliance",
    issuer: "451 Alliance · S&P Global Market Intelligence",
    dateLabel: "2026",
    file: "/documents/451-alliance-invitation.pdf",
    note: "Leading Indicator membership welcome letter",
  },
];

import type { Project } from "./types";

// Repository links are verified — each one was fetched and confirmed to
// exist and resolve to the described project before being added here.
// No repo link, stat, or technology is listed unless it traces back to
// either a supplied document or the live repository itself.
export const projects: Project[] = [
  {
    id: "career-guardian-ai",
    title: "Career Guardian AI",
    category: "Multi-agent AI system",
    why: "Job seekers get generic resume advice. This asks what a coordinated team of specialists would actually tell you.",
    what: "A production multi-agent application that analyzes a resume, maps a career direction, finds the skill gaps, and produces a personalized growth roadmap.",
    how: "Five specialist agents (Resume, Career, SkillGap, Roadmap, Resource), each an ADK-compatible BaseAgent, coordinated by an Orchestrator that runs a parallel phase and a sequential phase. Results stream to the client over Server-Sent Events. A four-layer security module sanitizes prompt-injection attempts across 11 patterns and enforces token-bucket rate limiting.",
    technologies: [
      "Python",
      "Google Gemini",
      "Server-Sent Events",
      "HTML/CSS/JS frontend",
      "Render.com",
    ],
    features: [
      "5 specialist agents + orchestrator (parallel + sequential phases)",
      "Real-time SSE streaming",
      "4-layer security module, 11-pattern prompt-injection defense",
    ],
    result: "Submitted to the Kaggle AI Agents Capstone Competition.",
    repository: "https://github.com/Samdarshil/Career-Guardian-AI",
    status: "verified-live",
  },
  {
    id: "oncai",
    title: "OncAI",
    category: "Applied ML · Full-stack",
    why: "Built during the DecodeLabs internship to take a classifier past a notebook and into something a clinician could actually open.",
    what: "A full-stack breast cancer classification system.",
    how: "A scikit-learn classifier ensemble served through FastAPI, with a React/TypeScript frontend, containerized and run through CI.",
    technologies: ["FastAPI", "React", "TypeScript", "scikit-learn", "Docker"],
    features: ["Classifier ensemble", "Docker + CI pipeline", "React frontend"],
    result: "96.5% classification accuracy.",
    repository:
      "https://github.com/Samdarshil/DecodeLabs-Internship-Projects/tree/main/Project%2002",
    status: "verified-live",
  },
  {
    id: "tech-stack-recommender",
    title: "Tech Stack Recommender",
    category: "Applied ML · Built from scratch",
    why: "Recommendation engines usually mean importing scikit-learn and calling it a day. This one builds the similarity math itself.",
    what: "A career-path / tech-stack recommender.",
    how: "TF-IDF vectorization with cosine and Jaccard similarity implemented from scratch — no scikit-learn in the core recommendation logic — served through a Flask UI.",
    technologies: ["Python", "Flask", "TF-IDF (from scratch)"],
    features: [
      "Cosine + Jaccard similarity, hand-implemented",
      "72 unit tests",
      "Flask UI",
    ],
    repository:
      "https://github.com/Samdarshil/DecodeLabs-Internship-Projects/tree/main/Project%2003",
    status: "verified-live",
  },
  {
    id: "decodebot",
    title: "DecodeBot",
    category: "Terminal application",
    why: "A terminal tool doesn't have to look like a terminal tool.",
    what: "A rule-based terminal AI assistant with a cinematic interface.",
    how: "Built in Python with colorama-driven terminal styling for a deliberately staged, cinematic feel rather than a bare REPL.",
    technologies: ["Python", "colorama"],
    features: ["Rule-based conversation engine", "Cinematic terminal UI"],
    repository:
      "https://github.com/Samdarshil/DecodeLabs-Internship-Projects/tree/main/Project%2001",
    status: "verified-live",
  },
  {
    id: "ocr-text-recognition",
    title: "OCR Text Recognition",
    category: "Computer vision",
    why: "Raw OCR output is noisy. The interesting part is what happens before and after the recognition call.",
    what: "A document text-extraction pipeline.",
    how: "OpenCV handles image preprocessing ahead of Tesseract OCR, with confidence filtering applied to the recognized output.",
    technologies: ["Python", "OpenCV", "Tesseract (pytesseract)"],
    features: ["Preprocessing pipeline", "Confidence filtering"],
    repository:
      "https://github.com/Samdarshil/DecodeLabs-Internship-Projects/tree/main/Project%2004",
    status: "verified-live",
  },
];

import type { EducationEntry } from "./types";

// Source: README.md, section 22 "EDUCATION STORY". No independent document
// was supplied for the pre-university stages, so this is filed at the
// "README / project specification" tier of the source-of-truth hierarchy —
// one step below an official document, one step above creative interpretation.
export const education: EducationEntry[] = [
  {
    id: "st-johns",
    institution: "St. John's School",
    place: "Baran, Rajasthan",
    period: "Kindergarten",
    detail: "Foundational manners, discipline and etiquette.",
  },
  {
    id: "st-pauls",
    institution: "St. Paul's Senior Secondary School",
    place: "Baran, Rajasthan",
    period: "Classes 1–10",
    detail:
      "The period where fascination with technology, superheroes and futuristic systems took hold.",
  },
  {
    id: "kv-baran",
    institution: "Kendriya Vidyalaya Baran",
    place: "Baran, Rajasthan",
    period: "Classes 11–12",
    detail: "Stream: PCB + Informatics Practices + English.",
    milestone: {
      title: "Railway Reservation System",
      description: "First meaningful programming creation.",
      technologies: ["Python", "SQL", "SQL Connector"],
    },
  },
  {
    id: "jnu",
    institution: "Jaipur National University",
    place: "Jaipur, Rajasthan",
    period: "BCA · 2025–2028",
    detail: "AI/ML specialization. Currently in 2nd year.",
  },
];

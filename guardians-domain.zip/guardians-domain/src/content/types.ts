// Guardian's Domain — content type definitions
//
// Every fact rendered in the experience should trace back to one of these
// records. Nothing here is invented: fields are either sourced from a
// supplied document, a verified repository, or the creator directly.
// See /src/content/README.md for the source of each file.

export interface LinkRef {
  label: string;
  url: string;
}

export interface Identity {
  professionalName: string;
  narrativeName: string;
  tagline: string;
  location: string;
  links: LinkRef[];
}

export interface EducationEntry {
  id: string;
  institution: string;
  place?: string;
  period: string;
  detail: string;
  /** Notable milestone tied to this stage, if any (e.g. a first project). */
  milestone?: {
    title: string;
    description: string;
    technologies: string[];
  };
}

export type ExperienceKind = "internship" | "membership";

export interface ExperienceEntry {
  id: string;
  organization: string;
  role: string;
  kind: ExperienceKind;
  /** Short label shown in the UI so a membership is never mislabeled as employment. */
  kindLabel: string;
  mode?: string;
  period: string;
  summary: string;
  highlights: string[];
  evidenceIds: string[];
}

export interface EvidenceDocument {
  id: string;
  title: string;
  issuer: string;
  dateLabel: string;
  /** Path under /public — the original, unaltered supplied document. */
  file: string;
  note?: string;
}

export interface Project {
  id: string;
  title: string;
  category: string;
  why: string;
  what: string;
  how: string;
  technologies: string[];
  features: string[];
  result?: string;
  repository?: string;
  demo?: string;
  status: "verified-live" | "in-progress";
}

export type WorldRegionId =
  | "the-heart"
  | "origin"
  | "the-forge"
  | "the-mind"
  | "orbit"
  | "archive"
  | "frontier"
  | "the-null";

export interface WorldRegion {
  id: WorldRegionId;
  name: string;
  focus: string;
  description: string;
  /** The Null is discovered, never listed in primary navigation. */
  hiddenFromNav?: boolean;
}

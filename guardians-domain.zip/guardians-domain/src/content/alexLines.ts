import type { WorldRegionId } from "./types";

/**
 * Alex is deterministic for now — see brief §35: deterministic systems for
 * standard dialogue and known facts, AI layered in later where it adds real
 * value. Every line here either comes verbatim from the brief (the intro)
 * or narrates something already true in world.ts/projects.ts — Alex never
 * gets a fact this file didn't already have verified.
 */

// Brief §10, verbatim — required, not a suggestion.
export const alexIntro: string[] = [
  "Alright... so this time, it's you.",
  "Welcome, traveler.",
];

// One line per visible region, in Alex's voice (§10: intelligent, calm,
// warm, curious, playful, confident, slightly mysterious). Content is
// narrative framing only — the facts underneath are whatever world.ts
// and the relevant content file already say.
export const alexRegionLines: Record<WorldRegionId, string> = {
  "the-heart":
    "This is the center of it — the Heart. Everything else in the Domain orbits back to who Guardian actually is.",
  origin:
    "Origin holds where this started. The curiosity, before any of it had a name yet.",
  "the-forge":
    "The Forge is where ideas stop being ideas. Everything built lives here.",
  "the-mind":
    "The Mind is the actual toolkit — what's really under the hood, not a list of buzzwords.",
  orbit:
    "Orbit tracks the professional record. Where Guardian has actually worked, and what came of it.",
  archive:
    "The Archive holds the paperwork. Nothing staged in here — every document is the real one.",
  frontier: "Frontier's unfinished on purpose. It's where this heads next.",
  "the-null":
    "...you weren't supposed to find this yet. Interesting.",
};

export const alexIdleLine =
  "No destination locked in. Pick one, and I'll tell you what's there.";

/**
 * Honest fallback for anything Alex doesn't actually have data for —
 * brief §11: "If he does not know something, say that he does not have
 * that information." No system calls this yet (nothing asks Alex free-form
 * questions), but it exists so nothing downstream is tempted to fabricate
 * one instead.
 */
export const alexUnknownLine =
  "I don't have that information yet — ask me again once it's actually built.";

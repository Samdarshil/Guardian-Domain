import { useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { Starfield } from "../scene/Starfield";
import { CockpitRig } from "../scene/CockpitRig";
import { Opening } from "../scene/Opening";
import { ModeToggle } from "../components/ModeToggle";
import { WindshieldFrame } from "../components/hud/WindshieldFrame";
import { NavReadout } from "../components/hud/NavReadout";
import { RadarWidget } from "../components/hud/RadarWidget";
import { DestinationPanel } from "../components/hud/DestinationPanel";
import { AlexDock } from "../components/hud/AlexDock";
import { identity } from "../content/identity";
import { useDomainStore } from "../state/useDomainStore";
import { isWebGLAvailable } from "../utils/webgl";
import "../styles/global.css";
import styles from "./App.module.css";

export default function App() {
  const [webglOk] = useState(() => isWebGLAvailable());
  const [openingDone, setOpeningDone] = useState(false);
  const setReducedMotion = useDomainStore((s) => s.setReducedMotion);

  useEffect(() => {
    // Only a change subscription — the store already computes the initial
    // value correctly, so there's nothing to set on mount here.
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, [setReducedMotion]);

  // The opening cinematic is presentation, not information, and WebGL-less
  // browsers get the accessible fallback straight away rather than a 3D
  // sequence they can't render.
  if (!openingDone && webglOk) {
    return <Opening onComplete={() => setOpeningDone(true)} />;
  }

  return (
    <div className={styles.root}>
      {webglOk ? (
        <Canvas
          className={styles.canvas}
          style={{ position: "absolute", inset: 0 }}
          camera={{ position: [0, 0, 8], fov: 55 }}
          gl={{ antialias: true, alpha: false }}
        >
          <color attach="background" args={["#04060b"]} />
          <CockpitRig>
            <Starfield />
          </CockpitRig>
        </Canvas>
      ) : (
        <div className={styles.fallbackBackdrop} aria-hidden="true" />
      )}

      {webglOk && <WindshieldFrame />}

      <div className={styles.hud}>
        <header className={`${styles.overlay} ${styles.bootIn}`}>
          <div>
            <p className={styles.eyebrow}>Guardian&apos;s Domain</p>
            <h1 className={styles.name}>{identity.professionalName}</h1>
            <p className={styles.tagline}>{identity.tagline}</p>
          </div>
          <ModeToggle />
        </header>

        <div className={`${styles.sideLeft} ${styles.bootIn}`} style={{ animationDelay: "0.15s" }}>
          <NavReadout />
          <DestinationPanel />
        </div>

        <div className={`${styles.sideRight} ${styles.bootIn}`} style={{ animationDelay: "0.3s" }}>
          <RadarWidget />
          <AlexDock />
        </div>

        <footer className={`${styles.status} ${styles.bootIn}`} style={{ animationDelay: "0.45s" }} aria-label="Build status">
          <p>
            Opening, cockpit, and Alex&apos;s intro are all real. Live radar
            signals, travel between regions, and Alex answering free-form
            questions are still ahead — see the project README.
          </p>
          {!webglOk && (
            <p role="status">
              3D rendering isn&apos;t available in this browser — showing the
              accessible fallback. Every panel here still works without it.
            </p>
          )}
        </footer>
      </div>
    </div>
  );
}

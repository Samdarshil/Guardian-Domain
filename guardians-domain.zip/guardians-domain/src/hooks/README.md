# Hooks

Not yet implemented. Reserved for shared React hooks (camera rigs, input
handling, audio, quality-tier detection) as those systems get built.

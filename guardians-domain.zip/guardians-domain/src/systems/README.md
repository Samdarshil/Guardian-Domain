# Systems

Not yet implemented. This is where the deterministic, non-visual systems from
the brief belong once they're built:

- Navigation / travel between world regions
- Radar (known / unknown / anomaly / transient signal states)
- Performance tiers (Ultra / High / Balanced / Lite / Accessible)
- Alex's dialogue system (deterministic core + AI layer over verified content)

Nothing here yet — do not assume any of this exists when building on top of
the current foundation.

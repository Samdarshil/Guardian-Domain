import { create } from "zustand";
import type { WorldRegionId } from "../content/types";

export type DomainMode = "normal" | "recruiter";

interface DomainState {
  mode: DomainMode;
  setMode: (mode: DomainMode) => void;

  activeRegion: WorldRegionId | null;
  setActiveRegion: (region: WorldRegionId | null) => void;

  /** Mirrors prefers-reduced-motion; scene systems should read this rather
   * than querying the media feature directly, so it stays overridable. */
  reducedMotion: boolean;
  setReducedMotion: (value: boolean) => void;
}

export const useDomainStore = create<DomainState>((set) => ({
  mode: "normal",
  setMode: (mode) => set({ mode }),

  activeRegion: null,
  setActiveRegion: (activeRegion) => set({ activeRegion }),

  reducedMotion:
    typeof window !== "undefined"
      ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
      : false,
  setReducedMotion: (reducedMotion) => set({ reducedMotion }),
}));
